module.exports = function (data) {
  return `
<footer>
  <p>
    Made with
    <a href="https://github.com/lit/lit-element-starter-js">lit-starter-js</a>
  </p>
</footer>`;
};
